Installation instructions
=========================

Here you have:
- A folder named pdi_labs with the transformation files developed in chapter 3
- A folder named pdi_files with sample files for the tutorials of chapter 3
- A kettle.properties file


Installation
============
- Copy the folder pdi_labs to your drive (c:/ or /home/<your_dir>/)
- Copy the folder pdi_files to c:/ or /home/<your_dir>/
- Edit the kettle.properties and uncomment the lines corresponding to your operating system
- Overwrite the kettle.properties file located in your home directory with this file.
